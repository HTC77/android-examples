<?php
$username = "root";
$password = "";
$hostName = "localhost";
$dbName = "dbupload";
$con = mysqli_connect($hostName, $username, $password, $dbName);
if ($con && isset($_POST["image"])) {
	$image = $_POST["image"];
	$name = $_POST["name"];
	$sql = "INSERT INTO imageinfo(name) VALUES('$name')";
	$uploadPath = "uploads/$name.jpg";
	if (mysqli_query($con, $sql)) {
		file_put_contents($uploadPath, base64_decode($image));
		echo json_encode(array ('response' => 'Image uploaded successfully'));
	}else{
		echo json_encode(array ('response' => 'Image upload failed' ));
	}
}else{
		echo json_encode(array ('response' => 'Image upload failed ERROR IN CONNECTION' ));
}

mysqli_close($con);