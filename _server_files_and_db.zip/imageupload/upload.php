<?php 
require "init.php";

if ($con && isset($_POST['title'])) {
	$title = $_POST['title'];
	$image = $_POST['image'];
	$uploadPath = "uploads/$title.jpg";

	$sql = "INSERT INTO `imageinfo`(`title`,`path`) VALUES('$title','$uploadPath')";

	if (mysqli_query($con,$sql)) {
		file_put_contents($uploadPath, base64_decode($image));
		echo json_encode(array('response' =>'Image uploaded successfully...'));
	}else{
		echo json_encode(array('response'=>'Image upload failed'));	
	}

	mysqli_close($con);
}
