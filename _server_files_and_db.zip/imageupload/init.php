<?php 
$username = "root";
$password = "";
$dbName = "imagedb";
$hostname = "localhost";

$con = mysqli_connect($hostname,$username,$password,$dbName);

// if ($con) {
// 	echo "Connection success...";
// }else{
// 	echo "Connection failed";
// }

